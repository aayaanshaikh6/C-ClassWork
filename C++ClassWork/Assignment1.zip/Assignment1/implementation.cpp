#include<iostream>
#include "header.h"
#include<string>
#include<array>

using namespace std;


Matrix::Matrix(){

  for(int i = 0; i < 3; i++){

    for(int j = 0; j < 3; j++){
      array[i][j] = (rand() % 10);

    }
  }
}

void Matrix::Print(){
  string p;
  for(int i = 0; i < 3; i++){
    for(int j = 0; j < 3; j++){
      p.append(to_string(array[i][j]));
      p.append(" ");

    }
    p.append("\n");
  }
  cout<<p<<endl;
}

Matrix Matrix::operator*(Matrix &a){
  Matrix b;
  for(int i = 0; i < 3; i++){

    for(int j = 0; j < 3; j++){
      int sum = 0;

      for(int k = 0; k < 3; k++){
        sum += ( (array[i][k] * a.array[k][j]) );

      }
      b.array[i][j] = sum;
    }
  }
    return b;
}

bool Matrix::operator==(Matrix &a){
  for(int i = 0; i < 3; i++){

    for(int j = 0; j < 3; j++){

      if( a.array[i][j] != array[i][j] ){
        return false;
      }
    }
  }
  return true;
}
