#include<iostream>
#include "header.h"

using namespace std;

int main(){
  Matrix kumquat;
  Matrix jackfruit = kumquat;

  cout<< "Matrix kumquat is:"<<endl;
  kumquat.Print();

  cout<< "Matrix jackfruit is:"<<endl;
  jackfruit.Print();

  Matrix durian = (kumquat * jackfruit);
  cout<< "Matrix durian, which equals Matrix kumquat times Matrix jackfruit, is:"<<endl;
  durian.Print();

  string word;
  bool isEquals = (kumquat == jackfruit);
  if(isEquals){
    word.append("true");
  }else{
    word.append("false");
  }
  cout<< "It is "<< word << " that Matrix kumquat equals Matrix jackfruit." <<endl;

  word = "";
  isEquals = (kumquat == durian);
  if(isEquals){
    word.append("true");
  }else{
    word.append("false");
  }

  cout<< "It is "<< word << " that Matrix kumquat equals Matrix durian." <<endl;

  return 0;
}
