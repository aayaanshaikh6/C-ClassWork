#ifndef HEADER_H
#define HEADER_H
#include<string>
#include<array>
#include<iostream>
using namespace std;

class Matrix{

  public:

  int array[3][3];

  Matrix();

  void Print();

  Matrix operator*(Matrix&a);

  bool operator==(Matrix&a);

};



#endif
