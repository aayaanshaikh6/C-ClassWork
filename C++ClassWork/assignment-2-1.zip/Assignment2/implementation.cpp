#include<iostream>
#include "header.h"
#include<string>
#include<array>

using namespace std;

ArrayList::ArrayList(){
    array[0] = 0;
}
ArrayList::~ArrayList(){
    delete[] array;
}

void ArrayList::toString(){
  string p;
  p.append("[ ");
  for(int i = 0; i < size; i++){
    p.append( (to_string(array[i]) + " ") );
  }
  p.append( "]");
  cout<<p<<endl;
}

void ArrayList::Push(int k){
  cout<<"pushed "<< k<<endl;

  if(occ >= size){
    int* arrayTemp = new int[size * 2];
    for(int i = 0; i < size * 2; i++){
      arrayTemp[i] = 0;
    }
    for(int i = 0; i < size; i++){
      arrayTemp[i] = array[i];
    }
    arrayTemp[occ] = k;
    occ ++;
    delete[] array;
    array = arrayTemp;
    size = size*2;
  }else{
    array[occ] = k;
    occ ++;
  }
}
void ArrayList::Erase(int k){
  cout<<"erased "<< k<<endl;

  for(int i = 0; i < occ; i++){
    if(array[i] == k){
      for(int j = i; j < size; j++){
        array[j] = array[j+1];
      }
      occ --;
      break;
    }
  }
  if(occ <= size/2){
    int* arrayTemp = new int[size / 2];
    for(int i = 0; i < size / 2; i++){
      arrayTemp[i] = 0;
    }
    for(int i = 0; i < size/2; i++){
      arrayTemp[i] = array[i];
    }
    delete[] array;
    size = size/2;
    array = arrayTemp;
  }
}
