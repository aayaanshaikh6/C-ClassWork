#ifndef HEADER_H
#define HEADER_H
#include<string>
#include<array>
#include<iostream>
using namespace std;

class ArrayList{

  public:

  int* array = new int[1];

  int occ = 0;

  int size = 1;

  ArrayList();

  ~ArrayList();

  void Erase(int m);

  void Push(int k);

  void toString();


};



#endif
