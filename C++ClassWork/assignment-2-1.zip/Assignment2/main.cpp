#include<iostream>
#include<ctime>
#include "header.h"

using namespace std;

int main(){

  ArrayList gon;

  gon.toString();
  gon.Push(1);
  gon.toString();
  gon.Push(2);
  gon.toString();
  gon.Push(3);
  gon.toString();
  gon.Push(4);
  gon.toString();
  gon.Push(5);
  gon.toString();
  gon.Push(6);
  gon.toString();
  gon.Push(7);
  gon.toString();
  gon.Push(8);
  gon.toString();
  gon.Push(9);
  gon.toString();
  gon.Push(0); //Using zero as both the placeholder and as a value you can store, if zero is at the end of the array you can't tell which it is untill the next Push or Erase method.
  gon.toString();
  gon.Push(5);
  gon.toString();
  gon.Erase(5);
  gon.toString();
  gon.Erase(1);
  gon.toString();
  gon.Erase(2);
  gon.toString();
  gon.Erase(3);
  gon.toString();
  gon.Erase(4);
  gon.toString();
  gon.Erase(5);
  gon.toString();
  gon.Erase(0);
  gon.toString();
  gon.Erase(0);
  gon.toString();
  gon.Erase(9);
  gon.toString();
  gon.Erase(0);
  gon.toString();

  /*
  srand((time(0)*(65486+3)));
  gon.Push(rand() % 10);
  gon.toString();
  srand((time(0)*(6546+3)));
  gon.Push(rand() % 10);
  gon.toString();
  srand((time(0)*(6486+3)));
  gon.Push(rand() % 10);
  gon.toString();
  srand((time(0)*(6548+3)));
  gon.Push(rand() % 10);
  gon.toString();

  for(int i = 0; i < 20; i++){
    srand((time(0)*(i*65486)+3));
    if((rand()%2) == 0){
      srand((time(0)*(i*65486)+3));
      gon.Push(rand() % 10);
      gon.toString();
    }else{
      srand((time(0)+i*65486)+3);
      gon.Erase(rand() % 10);
      gon.toString();
    }
  }
  */
  return 0;
}
