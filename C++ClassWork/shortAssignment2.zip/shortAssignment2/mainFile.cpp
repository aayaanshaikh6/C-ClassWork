#include<iostream>
#include "headerFile.h"

using namespace std;

int main() {
  Student rishi("rsaripa");
  rishi.email = "rishi.saripalle@ilstu.edu";
  rishi.name = "Rishi Saripalle";
  rishi.grade = 3.79;
  rishi.AddAddress( "Main Rd" , 101, 102 , "Chicago" , "Illinois" , "U.S.A" );
  rishi.Display();



  return 0;
}
