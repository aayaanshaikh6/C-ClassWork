#ifndef HEADERFILE_H
#define HEADERFILE_H
#include<string>
#include<iostream>
using namespace std;

class Address{
  public:

    string street;
    int homeNum;
    int aptNum;
    string city;
    string state;
    string country;

    Address(string sn, int hn, int an, string ct, string st, string cou);
    Address();
    void Display();
};

class Student{

  private:
    string studentId;
    Address address;

  public:
    string email;
    string name;
    double grade;

    Student(string id);
    void AddAddress(string sn, int hn, int an, string ct, string st, string cou);
    void Display();
};
#endif
