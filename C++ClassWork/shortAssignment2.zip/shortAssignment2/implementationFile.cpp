#include<iostream>
#include "headerFile.h"
#include<string>
using namespace std;

Address::Address(string sn, int hn, int an, string ct, string st, string cou){
  street = sn;
  homeNum = hn;
  aptNum = an;
  city = ct;
  state = st;
  country = cou;
}

Address::Address(){
  street = "Street";
  homeNum = 100;
  aptNum = 100;
  city = "City";
  state = "State";
  country = "Country";
}

void Address::Display(){
  cout<< "The address is: " << homeNum << " " << street << " apt "<< aptNum <<", "<< city << ", "<< state << ", "<< country <<endl;
}

Student::Student(string id){
  studentId = id;
}

void Student::AddAddress(string sn, int hn, int ann, string ct, string st, string cou){
  address.street = sn;
  address.homeNum = hn;
  address.aptNum = ann;
  address.city = ct;
  address.state = st;
  address.country = cou;
}

void Student::Display(){
  cout<< name << " - has student id: " << studentId << ", email: " << email << ", and final GPA of: " << grade << endl;
  address.Display();
}
